import React from "react"

export default function Footer() {
    return (
        <footer>&#169; 2022 #VANLIFE</footer>
    )
}